# Afeef Ansari — personal website

A simple, text-first personal site designed for GitHub Pages.

## Files

- `index.html` — homepage
- `projects.html` — project index
- `about.html` — background, interests, and activities
- `journal.html` — writing index
- `projects/` — individual project pages
- `style.css` — site styling
- `script.js` — small footer-year enhancement

## Publish on GitHub Pages

1. Download and extract the ZIP.
2. Open your repository: <https://github.com/AfeefAnsari/AfeefAnsari.github.io>
3. Replace the existing site files with the files in this folder. Keep the folder structure, especially `projects/`.
4. Commit the changes to the repository's publishing branch (usually `main`).
5. GitHub Pages should rebuild the site automatically.

Before publishing, review the About page and project descriptions for accuracy and add any images or documents you want to share. The fusor page is intentionally a high-level retrospective rather than an operational guide.

## Notes

- No external frameworks or build step are required.
- The site is responsive and works as a static GitHub Pages site.
- The Acoustic Time-Reversal concept is not included.
